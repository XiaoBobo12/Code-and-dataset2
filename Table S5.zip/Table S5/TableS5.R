setwd("D:/研究备份/研究3/成组序贯设计/模拟情景数据/参数epsilon和b的确定")
data.plot<-data.frame(matrix(nrow=1800,ncol=4))
colnames(data.plot)<-c("MERT.t1.t2","n1.div.n0","epsilon.b","Boundaries")
itr2=0
for(l in 1:6)
{
  load(paste("Scenario.epsilon.b.",l,".RData",sep=""))
  for(itr in 1:300)
  {
    sample.est=sample.est.all[[itr]]
    itr2=itr2+1
    if(sample.est$Parameters$t1==0&sample.est$Parameters$t2==4)
    {
      data.plot$MERT.t1.t2[itr2]="(0,4)"
    }
    else if(sample.est$Parameters$t1==1&sample.est$Parameters$t2==3)
    {
      data.plot$MERT.t1.t2[itr2]="(1,3)"
    }
    data.plot$n1.div.n0[itr2]=sample.est$Parameters$Allc
    data.plot$epsilon.b[itr2]=paste("(",sample.est$Parameters$interval.period,",,",sample.est$Parameters$split.interval.num,")",sep="")
    data.plot$Boundaries[itr2]=paste("(",round(sample.est$Parameters$boundary.list$upperbound[1],4),",",round(sample.est$Parameters$boundary.list$upperbound[2],4),")",sep="")
  }
}
data.plot2=data.plot[!duplicated(data.plot),]
data.plot2.balanced=data.plot2[data.plot2$n1.div.n0==1,]
colnames(data.plot2.balanced)[4]="Balanced.boundaries"
data.plot2.balanced=data.plot2.balanced[,c(1,3,4)]
data.plot2.unbalanced=data.plot2[data.plot2$n1.div.n0==2,]
colnames(data.plot2.unbalanced)[4]="Unbalanced.boundaries"
data.plot2.unbalanced=data.plot2.unbalanced[,c(1,3,4)]
data.plot.out=merge(data.plot2.balanced,data.plot2.unbalanced,by.y=c("MERT.t1.t2","epsilon.b"))
write.csv(data.plot.out,"TableS5.csv")