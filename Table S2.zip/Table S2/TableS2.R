rm(list=ls())
load("D:/研究备份/研究3/成组序贯设计/模拟情景数据/最大样本量精确性评估/Scenario.individual.lag.pattern.RData")
data.original<-data.frame(matrix(nrow=180,ncol=6))
colnames(data.original)<-c("Allc","Harzard.Ratio","MERT.t1.t2","TRUE.t1.t2","Scenario","Sample.power")
for(i in 1:120)
{
  simul.esti<-result.list[[i]][["simul.esti"]]
  data.original$Allc[i]=round(simul.esti$Parameters$nt/simul.esti$Parameters$nc)
  data.original$Harzard.Ratio[i]=simul.esti$Parameters$theta
  data.original$MERT.t1.t2[i]=paste("(",simul.esti$Parameters$t1,",",simul.esti$Parameters$t2,")")
  if(simul.esti$Parameters$t1.true==0|simul.esti$Parameters$t2.true==4)
  {
    data.original$TRUE.t1.t2[i]="[0,4]"
  }
  else if(simul.esti$Parameters$t1.true==1|simul.esti$Parameters$t2.true==3)
  {
    data.original$TRUE.t1.t2[i]="[1,3]"
  }
  else if(simul.esti$Parameters$t1.true==2|simul.esti$Parameters$t2.true==6)
  {
    data.original$TRUE.t1.t2[i]="[2,6]"
  }
  if(simul.esti$Parameters$a==1&simul.esti$Parameters$b==2)
  {
    data.original$Scenario[i]="Scenario 2"
  }
  else if(simul.esti$Parameters$a==1&simul.esti$Parameters$b==1)
  {
    data.original$Scenario[i]="Scenario 3"
  }
  else if(simul.esti$Parameters$a==2&simul.esti$Parameters$b==1)
  {
    data.original$Scenario[i]="Scenario 4"
  }
  n=simul.esti$Parameters$nc+simul.esti$Parameters$nt
  Empirical.power=simul.esti$Power
  data.original$Sample.power[i]=paste(n,"(",Empirical.power,")",sep="")
}
load("D:/研究备份/研究3/成组序贯设计/模拟情景数据/最大样本量精确性评估/Scenario.individual.lag.pattern.supp.RData")
for(i in 121:180)
{
  simul.esti<-result.list[[i-120]][["simul.esti"]]
  data.original$Allc[i]=round(simul.esti$Parameters$nt/simul.esti$Parameters$nc)
  data.original$Harzard.Ratio[i]=simul.esti$Parameters$theta
  data.original$MERT.t1.t2[i]=paste("(",simul.esti$Parameters$t1,",",simul.esti$Parameters$t2,")")
  if(simul.esti$Parameters$t1.true==0|simul.esti$Parameters$t2.true==4)
  {
    data.original$TRUE.t1.t2[i]="[0,4]"
  }
  else if(simul.esti$Parameters$t1.true==1|simul.esti$Parameters$t2.true==3)
  {
    data.original$TRUE.t1.t2[i]="[1,3]"
  }
  else if(simul.esti$Parameters$t1.true==2|simul.esti$Parameters$t2.true==6)
  {
    data.original$TRUE.t1.t2[i]="[2,6]"
  }
  if(simul.esti$Parameters$a==1&simul.esti$Parameters$b==2)
  {
    data.original$Scenario[i]="Scenario 2"
  }
  else if(simul.esti$Parameters$a==1&simul.esti$Parameters$b==1)
  {
    data.original$Scenario[i]="Scenario 3"
  }
  else if(simul.esti$Parameters$a==2&simul.esti$Parameters$b==1)
  {
    data.original$Scenario[i]="Scenario 4"
  }
  n=simul.esti$Parameters$nc+simul.esti$Parameters$nt
  Empirical.power=simul.esti$Power
  data.original$Sample.power[i]=paste(n,"(",Empirical.power,")",sep="")
}
library(reshape)
data.results<-cast(data=data.original,formula =Allc+Harzard.Ratio+MERT.t1.t2+TRUE.t1.t2~Scenario)
data.results<-data.results[order(data.results$MERT.t1.t2,data.results$TRUE.t1.t2,data.results$Allc,data.results$Harzard.Ratio),]
write.csv(x=data.results,file="D:/TableS2.csv")