setwd("D:/研究备份/研究3/成组序贯设计/模拟情景数据/成组序贯边界评估/相对于生存函数")
load("Scenario2.Markov.chain.RData")
Mean.matrix<-data.frame(matrix(nrow= 2904,ncol=7))
colnames(Mean.matrix)<-c("k","h0","n1.div.n0","Tstar","Method","Analysis","Mean")
Variance.matrix<-data.frame(matrix(nrow=2904,ncol=7))
colnames(Variance.matrix)<-c("k","h0","n1.div.n0","Tstar","Method","Analysis","Variance")
covariance.matrix<-data.frame(matrix(nrow=2420,ncol=7))
colnames(covariance.matrix)<-c("k","h0","n1.div.n0","Tstar","Method","Type","Covariance")
for(i in 1:484)
{
  boundary.list=list.result[[i]]$boundary.list
  simul.res=list.result[[i]]$simul.res
  Mean.matrix$k[i*2-1]=simul.res$Parameters$k
  Mean.matrix$k[i*2]=simul.res$Parameters$k
  Mean.matrix$h0[i*2-1]=simul.res$Parameters$h0
  Mean.matrix$h0[i*2]=simul.res$Parameters$h0
  Mean.matrix$n1.div.n0[i*2-1]=simul.res$Parameters$nt/simul.res$Parameters$nc
  Mean.matrix$n1.div.n0[i*2]=simul.res$Parameters$nt/simul.res$Parameters$nc
  Mean.matrix$Tstar[i*2-1]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  Mean.matrix$Tstar[i*2]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  Mean.matrix$Method[i*2-1]="Markov chain-based method"
  Mean.matrix$Method[i*2]="Markov chain-based method"
  Mean.matrix$Analysis[i*2-1]="Interim~analysis"
  Mean.matrix$Analysis[i*2]="Final~analysis"
  Mean.matrix$Mean[i*2-1]=simul.res$Distribution$mean.test.statistics.std[1]
  Mean.matrix$Mean[i*2]=simul.res$Distribution$mean.test.statistics.std[2]
  Variance.matrix$k[i*2-1]=simul.res$Parameters$k
  Variance.matrix$k[i*2]=simul.res$Parameters$k
  Variance.matrix$h0[i*2-1]=simul.res$Parameters$h0
  Variance.matrix$h0[i*2]=simul.res$Parameters$h0
  Variance.matrix$n1.div.n0[i*2-1]=simul.res$Parameters$nt/simul.res$Parameters$nc
  Variance.matrix$n1.div.n0[i*2]=simul.res$Parameters$nt/simul.res$Parameters$nc
  Variance.matrix$Tstar[i*2-1]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  Variance.matrix$Tstar[i*2]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  Variance.matrix$Method[i*2-1]="Markov chain-based method"
  Variance.matrix$Method[i*2]="Markov chain-based method"
  Variance.matrix$Analysis[i*2-1]="Interim~analysis"
  Variance.matrix$Analysis[i*2]="Final~analysis"
  Variance.matrix$Variance[i*2-1]=simul.res$Distribution$Var.test.statistics.matrix.std[1,1]
  Variance.matrix$Variance[i*2]=simul.res$Distribution$Var.test.statistics.matrix.std[1,1]
  covariance.matrix$k[i*2-1]=simul.res$Parameters$k
  covariance.matrix$k[i*2]=simul.res$Parameters$k
  covariance.matrix$h0[i*2-1]=simul.res$Parameters$h0
  covariance.matrix$h0[i*2]=simul.res$Parameters$h0
  covariance.matrix$n1.div.n0[i*2-1]=simul.res$Parameters$nt/simul.res$Parameters$nc
  covariance.matrix$n1.div.n0[i*2]=simul.res$Parameters$nt/simul.res$Parameters$nc
  covariance.matrix$Tstar[i*2-1]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  covariance.matrix$Tstar[i*2]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  covariance.matrix$Method[i*2-1]="Markov~chain-based~method"
  covariance.matrix$Method[i*2]="Markov~chain-based~method"
  covariance.matrix$Type[i*2-1]="Asymptotical"
  covariance.matrix$Type[i*2]="Empirical"
  covariance.matrix$Covariance[i*2-1]=boundary.list$covariance.matrix[1,2]
  covariance.matrix$Covariance[i*2]=simul.res$Distribution$Var.test.statistics.matrix.std[1,2]
}
load("Scenario2.integration.RData")
for(i in 1:484)
{
  boundary.list=list.result[[i]]$boundary.list
  simul.res=list.result[[i]]$simul.res
  Mean.matrix$k[968+i*2-1]=simul.res$Parameters$k
  Mean.matrix$k[968+i*2]=simul.res$Parameters$k
  Mean.matrix$h0[968+i*2-1]=simul.res$Parameters$h0
  Mean.matrix$h0[968+i*2]=simul.res$Parameters$h0
  Mean.matrix$n1.div.n0[968+i*2-1]=simul.res$Parameters$nt/simul.res$Parameters$nc
  Mean.matrix$n1.div.n0[968+i*2]=simul.res$Parameters$nt/simul.res$Parameters$nc
  Mean.matrix$Tstar[968+i*2-1]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  Mean.matrix$Tstar[968+i*2]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  Mean.matrix$Method[968+i*2-1]="Integration-based method"
  Mean.matrix$Method[968+i*2]="Integration-based method"
  Mean.matrix$Analysis[968+i*2-1]="Interim~analysis"
  Mean.matrix$Analysis[968+i*2]="Final~analysis"
  Mean.matrix$Mean[968+i*2-1]=simul.res$Distribution$mean.test.statistics.std[1]
  Mean.matrix$Mean[968+i*2]=simul.res$Distribution$mean.test.statistics.std[2]
  Variance.matrix$k[968+i*2-1]=simul.res$Parameters$k
  Variance.matrix$k[968+i*2]=simul.res$Parameters$k
  Variance.matrix$h0[968+i*2-1]=simul.res$Parameters$h0
  Variance.matrix$h0[968+i*2]=simul.res$Parameters$h0
  Variance.matrix$n1.div.n0[968+i*2-1]=simul.res$Parameters$nt/simul.res$Parameters$nc
  Variance.matrix$n1.div.n0[968+i*2]=simul.res$Parameters$nt/simul.res$Parameters$nc
  Variance.matrix$Tstar[968+i*2-1]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  Variance.matrix$Tstar[968+i*2]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  Variance.matrix$Method[968+i*2-1]="Integration-based method"
  Variance.matrix$Method[968+i*2]="Integration-based method"
  Variance.matrix$Analysis[968+i*2-1]="Interim~analysis"
  Variance.matrix$Analysis[968+i*2]="Final~analysis"
  Variance.matrix$Variance[968+i*2-1]=simul.res$Distribution$Var.test.statistics.matrix.std[1,1]
  Variance.matrix$Variance[968+i*2]=simul.res$Distribution$Var.test.statistics.matrix.std[1,1]
  covariance.matrix$k[968+i*2-1]=simul.res$Parameters$k
  covariance.matrix$k[968+i*2]=simul.res$Parameters$k
  covariance.matrix$h0[968+i*2-1]=simul.res$Parameters$h0
  covariance.matrix$h0[968+i*2]=simul.res$Parameters$h0
  covariance.matrix$n1.div.n0[968+i*2-1]=simul.res$Parameters$nt/simul.res$Parameters$nc
  covariance.matrix$n1.div.n0[968+i*2]=simul.res$Parameters$nt/simul.res$Parameters$nc
  covariance.matrix$Tstar[968+i*2-1]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  covariance.matrix$Tstar[968+i*2]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  covariance.matrix$Method[968+i*2-1]="Integration-based~method"
  covariance.matrix$Method[968+i*2]="Integration-based~method"
  covariance.matrix$Type[968+i*2-1]="Asymptotical"
  covariance.matrix$Type[968+i*2]="Empirical"
  covariance.matrix$Covariance[968+i*2-1]=boundary.list$covariance.matrix[1,2]
  covariance.matrix$Covariance[968+i*2]=simul.res$Distribution$Var.test.statistics.matrix.std[1,2]
}
load("Scenario2.simulation.RData")
for(i in 1:484)
{
  simul.res=list.result[[i]]$simul.res
  Mean.matrix$k[1936+i*2-1]=simul.res$Parameters$k
  Mean.matrix$k[1936+i*2]=simul.res$Parameters$k
  Mean.matrix$h0[1936+i*2-1]=simul.res$Parameters$h0
  Mean.matrix$h0[1936+i*2]=simul.res$Parameters$h0
  Mean.matrix$n1.div.n0[1936+i*2-1]=simul.res$Parameters$nt/simul.res$Parameters$nc
  Mean.matrix$n1.div.n0[1936+i*2]=simul.res$Parameters$nt/simul.res$Parameters$nc
  Mean.matrix$Tstar[1936+i*2-1]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  Mean.matrix$Tstar[1936+i*2]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  Mean.matrix$Method[1936+i*2-1]="Simulation-based method"
  Mean.matrix$Method[1936+i*2]="Simulation-based method"
  Mean.matrix$Analysis[1936+i*2-1]="Interim~analysis"
  Mean.matrix$Analysis[1936+i*2]="Final~analysis"
  Mean.matrix$Mean[1936+i*2-1]=simul.res$Distribution$mean.test.statistics.std[1]
  Mean.matrix$Mean[1936+i*2]=simul.res$Distribution$mean.test.statistics.std[2]
  Variance.matrix$k[1936+i*2-1]=simul.res$Parameters$k
  Variance.matrix$k[1936+i*2]=simul.res$Parameters$k
  Variance.matrix$h0[1936+i*2-1]=simul.res$Parameters$h0
  Variance.matrix$h0[1936+i*2]=simul.res$Parameters$h0
  Variance.matrix$n1.div.n0[1936+i*2-1]=simul.res$Parameters$nt/simul.res$Parameters$nc
  Variance.matrix$n1.div.n0[1936+i*2]=simul.res$Parameters$nt/simul.res$Parameters$nc
  Variance.matrix$Tstar[1936+i*2-1]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  Variance.matrix$Tstar[1936+i*2]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  Variance.matrix$Method[1936+i*2-1]="Simulation-based method"
  Variance.matrix$Method[1936+i*2]="Simulation-based method"
  Variance.matrix$Analysis[1936+i*2-1]="Interim~analysis"
  Variance.matrix$Analysis[1936+i*2]="Final~analysis"
  Variance.matrix$Variance[1936+i*2-1]=simul.res$Distribution$Var.test.statistics.matrix.std[1,1]
  Variance.matrix$Variance[1936+i*2]=simul.res$Distribution$Var.test.statistics.matrix.std[1,1]
  covariance.matrix$k[1936+i]=simul.res$Parameters$k
  covariance.matrix$h0[1936+i]=simul.res$Parameters$h0
  covariance.matrix$n1.div.n0[1936+i]=simul.res$Parameters$nt/simul.res$Parameters$nc
  covariance.matrix$Tstar[1936+i]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  covariance.matrix$Method[1936+i]="Simulation-based method"
  covariance.matrix$Type[1936+i]="Empirical"
  covariance.matrix$Covariance[1936+i]=simul.res$Distribution$Var.test.statistics.matrix.std[1,2]
}
Mean.matrix$Tstar.order[Mean.matrix$Tstar=="[1,3]"]=1
Mean.matrix$Tstar.order[Mean.matrix$Tstar=="[0,4]"]=2
Mean.matrix$Tstar.order=factor(Mean.matrix$Tstar.order)
levels(Mean.matrix$Tstar.order)[levels(Mean.matrix$Tstar.order)==1]=expression(list(italic(t)[1]^"#"==1,italic(t)[2]^"#"==3))
levels(Mean.matrix$Tstar.order)[levels(Mean.matrix$Tstar.order)==2]=expression(list(italic(t)[1]^"#"==0,italic(t)[2]^"#"==4))
levels.Allc<-rep(NA,2)
levels.Allc[1]<-"italic(n)[1*italic(K)]/italic(n)[0*italic(K)]==1"
levels.Allc[2]<-"italic(n)[1*italic(K)]/italic(n)[0*italic(K)]==2"
Mean.matrix$Allc[Mean.matrix$n1.div.n0==1]=levels.Allc[1]
Mean.matrix$Allc[Mean.matrix$n1.div.n0==2]=levels.Allc[2]
library(ggplot2)
dev.set()
bitmap("D:/BoshengLi_FigureS8.jpeg",type="jpeg",height =16 ,width=12,res=800)
p1<-ggplot(data=Mean.matrix,aes(x=k,y=h0))+geom_raster(aes(fill=Mean),interpolate = TRUE)+scale_fill_gradientn(colours =c("purple","blue","cyan","green","yellow","orange","red"))+theme(legend.text=element_text(size=17),legend.title=element_text(size=17),axis.text=element_text(size=16),axis.title=element_text(size=17),strip.text=element_text(size=16))
p1<-p1+labs(fill=paste("Empirical mean"))+xlab(expression(x=italic(k)))+ylab(expression(y=italic(h)[0]))
p1<-p1+facet_grid(Analysis+Tstar.order~Allc,labeller = label_parsed)
p1
dev.off()
Variance.matrix$Tstar.order[Variance.matrix$Tstar=="[1,3]"]=1
Variance.matrix$Tstar.order[Variance.matrix$Tstar=="[0,4]"]=2
Variance.matrix$Tstar.order=factor(Variance.matrix$Tstar.order)
levels(Variance.matrix$Tstar.order)[levels(Variance.matrix$Tstar.order)==1]=expression(list(italic(t)[1]^"#"==1,italic(t)[2]^"#"==3))
levels(Variance.matrix$Tstar.order)[levels(Variance.matrix$Tstar.order)==2]=expression(list(italic(t)[1]^"#"==0,italic(t)[2]^"#"==4))
levels.Allc<-rep(NA,2)
levels.Allc[1]<-"italic(n)[1*italic(K)]/italic(n)[0*italic(K)]==1"
levels.Allc[2]<-"italic(n)[1*italic(K)]/italic(n)[0*italic(K)]==2"
Variance.matrix$Allc[Variance.matrix$n1.div.n0==1]=levels.Allc[1]
Variance.matrix$Allc[Variance.matrix$n1.div.n0==2]=levels.Allc[2]
dev.set()
bitmap("D:/BoshengLi_FigureS9.jpeg",type="jpeg",height =16 ,width=12,res=800)
p2<-ggplot(data=Variance.matrix,aes(x=k,y=h0))+geom_raster(aes(fill=Variance),interpolate = TRUE)+scale_fill_gradientn(colours =c("purple","blue","cyan","green","yellow","orange","red"))+theme(legend.text=element_text(size=17),legend.title=element_text(size=17),axis.text=element_text(size=16),axis.title=element_text(size=17),strip.text=element_text(size=16))
p2<-p2+labs(fill=paste("Empirical variance"))+xlab(expression(x=italic(k)))+ylab(expression(y=italic(h)[0]))
p2<-p2+facet_grid(Analysis+Tstar.order~Allc,labeller = label_parsed)
p2
dev.off()
covariance.matrix$Tstar.order[covariance.matrix$Tstar=="[1,3]"]=1
covariance.matrix$Tstar.order[covariance.matrix$Tstar=="[0,4]"]=2
covariance.matrix$Tstar.order=factor(covariance.matrix$Tstar.order)
levels(covariance.matrix$Tstar.order)[levels(covariance.matrix$Tstar.order)==1]=expression(list(italic(t)[1]^"#"==1,italic(t)[2]^"#"==3))
levels(covariance.matrix$Tstar.order)[levels(covariance.matrix$Tstar.order)==2]=expression(list(italic(t)[1]^"#"==0,italic(t)[2]^"#"==4))
levels.Allc<-rep(NA,2)
levels.Allc[1]<-"italic(n)[1*italic(K)]/italic(n)[0*italic(K)]==1"
levels.Allc[2]<-"italic(n)[1*italic(K)]/italic(n)[0*italic(K)]==2"
covariance.matrix$Allc[covariance.matrix$n1.div.n0==1]=levels.Allc[1]
covariance.matrix$Allc[covariance.matrix$n1.div.n0==2]=levels.Allc[2]
covariance.matrix$Type[covariance.matrix$Type=="Asymptotical"]=covariance.matrix$Method[covariance.matrix$Type=="Asymptotical"]
dev.set()
bitmap("D:/BoshengLi_FigureS10.jpeg",type="jpeg",height =15,width=13,res=800)
p3<-ggplot(data=covariance.matrix,aes(x=k,y=h0))+geom_raster(aes(fill=Covariance),interpolate = TRUE)+scale_fill_gradientn(colours =c("purple","blue","cyan","green","yellow","orange","red"))+theme(legend.text=element_text(size=17),legend.title=element_text(size=17),axis.text=element_text(size=16),axis.title=element_text(size=17),strip.text=element_text(size=16))
p3<-p3+labs(fill=paste("Covariance"))+xlab(expression(x=italic(k)))+ylab(expression(y=italic(h)[0]))
p3<-p3+facet_grid(Allc+Tstar.order~Type,labeller = label_parsed)
p3
dev.off()