.result.plot<-list()
load("Scenario11.RData")
list.result.plot[[1]]<-list.result
load("Scenario12.RData")
list.result.plot[[2]]<-list.result
load("Scenario21.RData")
list.result.plot[[3]]<-list.result
load("Scenario22.RData")
list.result.plot[[4]]<-list.result
load("Scenario31.RData")
list.result.plot[[5]]<-list.result
load("Scenario32.RData")
list.result.plot[[6]]<-list.result
results<-data.frame(matrix(nrow=186,ncol=7))
colnames(results)<-c("n","n1.div.n0","Type.one.error","t1","t2","Tstar","Allc")
for(j in 1:6)
{
  for(l in 1:31)
  {
    results[(j-1)*31+l,1]=list.result.plot[[j]][[l]]$Parameters$nc+list.result.plot[[j]][[l]]$Parameters$nt
    results[(j-1)*31+l,2]=list.result.plot[[j]][[l]]$Parameters$nt/list.result.plot[[j]][[l]]$Parameters$nc
    results[(j-1)*31+l,3]=list.result.plot[[j]][[l]]$Power
    results[(j-1)*31+l,4]=list.result.plot[[j]][[l]]$Parameters$t1
    results[(j-1)*31+l,5]=list.result.plot[[j]][[l]]$Parameters$t2
  }
}
levels.Allc<-rep(NA,2)
levels.Allc[1]<-"italic(n)[1*italic(K)]/italic(n)[0*italic(K)]==1"
levels.Allc[2]<-"italic(n)[1*italic(K)]/italic(n)[0*italic(K)]==2"
results$Allc[results$n1.div.n0==1]=levels.Allc[1]
results$Allc[results$n1.div.n0==2]=levels.Allc[2]
levels.tstar<-rep(NA,3)
levels.tstar[1]<-expression(list(italic(t)[1]^"#"==0,italic(t)[2]^"#"==3))
levels.tstar[2]<-expression(list(italic(t)[1]^"#"==3,italic(t)[2]^"#"==6))
levels.tstar[3]<-expression(list(italic(t)[1]^"#"==6,italic(t)[2]^"#"==9))
results$Tstar[results$t1==0&results$t2==3]="1"
results$Tstar[results$t1==3&results$t2==6]="2"
results$Tstar[results$t1==6&results$t2==9]="3"
library(ggplot2)
dev.set()
pdf("D:/BoshengLi_FigureA6.pS12",height =12.36 ,width = 12)
p<-ggplot(data=results,aes(x=n,y=Type.one.error,colour=Tstar))+geom_line(size=3)+scale_color_discrete(labels=levels.tstar)+geom_point(size=2)+labs(colour=expression(paste(italic(t)[1]^"#"," and ",italic(t)[2]^"#"," of ","MERT")))+theme(legend.text=element_text(size=19),legend.title=element_text(size=20),axis.text=element_text(size=19),axis.title=element_text(size=20),strip.text=element_text(size=19))+xlab("Maximum sample size")+ylab(paste("Empirical type ",as.roman(1)," error rate",sep=""))
p<-p+facet_wrap(.~Allc,labeller = label_parsed,ncol=1)
p
dev.off()