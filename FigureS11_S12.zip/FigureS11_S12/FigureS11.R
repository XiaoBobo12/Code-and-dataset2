source("~/Simulation.inferior.algorithm.R")
k=1.1
h0=log(2)^(1/k)/18
t1.true=3
t2.true=6
a=1
b=1
theta1=5
theta2.fun<-function(theta2,k,h0,t1.true,t2.true,theta1,a,b)
{
  surv.ctr<-survival.function.control(60,k,h0)
  surv.trt<-survival.function.treatment(60,k,h0,t1.true,t2.true,theta1,theta2,a,b)
  print(theta2)
  print(surv.ctr-surv.trt)
  return(surv.ctr-surv.trt)
}
theta2=round(uniroot(theta2.fun,interval = c(0.01,0.9),k=k,h0=h0,t1.true=t1.true,t2.true=t2.true,theta1=theta1,a=a,b=b)$root,4)
t.vec<-seq(0,60,1.5)
surv.ctr<-survival.function.control(t.vec,k,h0)
surv.trt<-survival.function.treatment(t.vec,k,h0,t1.true,t2.true,theta1,theta2,a,b)
data.plot.frame=data.frame(matrix(nrow=82,ncol=3))
colnames(data.plot.frame)=c("Group","Survival.time","Survival.Prop")
for(i in 1:41)
{
  data.plot.frame$Group[i]="Control therapy"
  data.plot.frame$Survival.time[i]=t.vec[i]
  data.plot.frame$Survival.Prop[i]=surv.ctr[i]
}
for(i in 42:82)
{
  data.plot.frame$Group[i]="Immunotherapy"
  data.plot.frame$Survival.time[i]=t.vec[i-41]
  data.plot.frame$Survival.Prop[i]=surv.trt[i-41]
}
library(ggplot2)
dev.set()
pdf("D:/BoshengLi_FigureS11.pdf",height =6.18 ,width = 11)
p<-ggplot(data=data.plot.frame,aes(x=Survival.time,y=Survival.Prop,colour=Group))+geom_line(size=1)+xlab("Survival Time")+ylab("Overall survival(%)")
p
dev.off()