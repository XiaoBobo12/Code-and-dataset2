rm(list=ls())
setwd("/home/user1/LBS17")
source("Design.algorithm.parallel.R")
n.vec=seq(100,2100,200)
A=24
tau.vector=c(36,60)
split.interval.num=10
interval.period=0.1
loss.control=0.0074
loss.treatment=0.0074
k=1.1
h0=log(2)^(1/k)/18
delay.true.range.matrix<-rbind(c(0,4),c(1,3),c(2,6))
MERT.range.matrix<-rbind(c(0,4),c(1,3))
theta.vector=c(0.4,0.5,0.6,0.7,0.8)
#a.b.matrix<-rbind(c(1,1),c(1,1),c(1,1),c(1,2),c(2,1))
a.b.matrix<-rbind(c(1,1),c(1,2),c(1,1),c(2,1),c(1,1))
Allc.vec=c(1,2)
test.type=2
Phi.type=2
alpha=0.025
alpha.allc<-c(0.5,0.5)
sides=1
Result.matrix=data.frame(matrix(nrow =3300,ncol=11))
colnames(Result.matrix)=c("n","sqrt.n","power","qnorm.power","Allc","Delayed.treatment.pattern","Hazard.ratio","t1.true","t2.true","t1.MERT","t2.MERT")
z=0
for(g in 1:3)
{
  t1.true<-delay.true.range.matrix[g,1]
  t2.true<-delay.true.range.matrix[g,2]
  #  t.sep.true.mtrix<-rbind(c(t1.true,t1.true),c(t2.true,t2.true),c(t1.true,t2.true),c(t1.true,t2.true),c(t1.true,t2.true))
  t.sep.true.mtrix<-rbind(c(t1.true,t1.true),c(t1.true,t2.true),c(t1.true,t2.true),c(t1.true,t2.true),c(t2.true,t2.true))
  for(h in 1:2)
  {
    t1=MERT.range.matrix[h,1]
    t2=MERT.range.matrix[h,2]
    for(i in 1:2)
    {
      boundary.list<-group.sequential.boundary.by.markov.chain(tau.vector=tau.vector,A=A,split.interval.num=split.interval.num,interval.period=interval.period,loss.control=loss.control,loss.treatment=loss.treatment,k=k,h0=h0,t1=t1,t2=t2,Allc=Allc.vec[i],test.type=test.type,Phi.type=Phi.type,alpha=alpha,alpha.allc=alpha.allc,sides=sides)
      bound.list<-boundary.list$bound.list
      for(j in 1:5)
      {
        for(l in 1:11)
        {
          for(m in 1:5)
          {
            z=z+1
            power.res<-power.calculation.group.sequential.design.by.marcov.chain(n.vec[l],A,tau.vector,boundary.list=bound.list,split.interval.num,interval.period,loss.control,loss.treatment,k,h0,t1,t1.true=t.sep.true.mtrix[j,1],t2,t2.true=t.sep.true.mtrix[j,2],theta=theta.vector[m],a=a.b.matrix[j,1],b=a.b.matrix[j,2],Allc=Allc.vec[i],test.type,Phi.type)$Power
            Result.matrix[z,]<-c(n.vec[l],sqrt(n.vec[l]),power.res,qnorm(power.res),Allc.vec[i],j,theta.vector[m],t1.true,t2.true,t1,t2)
            print(paste(z,"/3300"))
          }
        }
        save.image("Figure3.RData")
      }
    }
  }
}
save.image("Figure3.RData")
Lag.range.num<-rep(NA,3300)
MERT.num<-rep(NA,3300)
for(i in 1:3300)
{
  t1.true=Result.matrix$t1.true[i]
  t2.true=Result.matrix$t2.true[i]
  Lag.range.num[i]=Result.matrix$Delayed.treatment.pattern[i]*100+Result.matrix$t1.true[i]*10+Result.matrix$t2.true[i]
  t1.MERT=Result.matrix$t1.MERT
  t2.MERT=Result.matrix$t2.MERT
  MERT.num[i]=ifelse(Result.matrix$t1.MERT[i]==0,1,2)
}
Result.matrix<-cbind(Result.matrix,Lag.range.num,MERT.num)
Result.frame<-Result.matrix[!is.infinite(Result.matrix[,4]),]
Result.frame$Allc<-factor(Result.frame$Allc)
levels(Result.frame$Allc)[levels(Result.frame$Allc)=="1"]<-"italic(n)[1][italic(K)] / italic(n)[0][italic(K)]==1"
levels(Result.frame$Allc)[levels(Result.frame$Allc)=="2"]<-"italic(n)[1][italic(K)] / italic(n)[0][italic(K)]==2"
Result.frame$Hazard.ratio=factor(Result.frame$Hazard.ratio)
levels(Result.frame$Hazard.ratio)[levels(Result.frame$Hazard.ratio)=="0.4"]="lambda==0.4"
levels(Result.frame$Hazard.ratio)[levels(Result.frame$Hazard.ratio)=="0.5"]="lambda==0.5"
levels(Result.frame$Hazard.ratio)[levels(Result.frame$Hazard.ratio)=="0.6"]="lambda==0.6"
levels(Result.frame$Hazard.ratio)[levels(Result.frame$Hazard.ratio)=="0.7"]="lambda==0.7"
levels(Result.frame$Hazard.ratio)[levels(Result.frame$Hazard.ratio)=="0.8"]="lambda==0.8"
Result.frame$Lag.range.num=factor(Result.frame$Lag.range.num)
Lag.spec<-rep(NA,15)
Lag.spec[1]=expression(paste("Scenario ",1," (",list(italic(t)[1]^"*"==0,italic(t)[2]^"*"==4),")",sep=""))
Lag.spec[2]=expression(paste("Scenario ",1," (",list(italic(t)[1]^"*"==1,italic(t)[2]^"*"==3),")",sep=""))
Lag.spec[3]=expression(paste("Scenario ",1," (",list(italic(t)[1]^"*"==2,italic(t)[2]^"*"==6),")",sep=""))
Lag.spec[4]=expression(paste("Scenario ",2," (",list(italic(t)[1]^"*"==0,italic(t)[2]^"*"==4),")",sep=""))
Lag.spec[5]=expression(paste("Scenario ",2," (",list(italic(t)[1]^"*"==1,italic(t)[2]^"*"==3),")",sep=""))
Lag.spec[6]=expression(paste("Scenario ",2," (",list(italic(t)[1]^"*"==2,italic(t)[2]^"*"==6),")",sep=""))
Lag.spec[7]=expression(paste("Scenario ",3," (",list(italic(t)[1]^"*"==0,italic(t)[2]^"*"==4),")",sep=""))
Lag.spec[8]=expression(paste("Scenario ",3," (",list(italic(t)[1]^"*"==1,italic(t)[2]^"*"==3),")",sep=""))
Lag.spec[9]=expression(paste("Scenario ",3," (",list(italic(t)[1]^"*"==2,italic(t)[2]^"*"==6),")",sep=""))
Lag.spec[10]=expression(paste("Scenario ",4," (",list(italic(t)[1]^"*"==0,italic(t)[2]^"*"==4),")",sep=""))
Lag.spec[11]=expression(paste("Scenario ",4," (",list(italic(t)[1]^"*"==1,italic(t)[2]^"*"==3),")",sep=""))
Lag.spec[12]=expression(paste("Scenario ",4," (",list(italic(t)[1]^"*"==2,italic(t)[2]^"*"==6),")",sep=""))
Lag.spec[13]=expression(paste("Scenario ",5," (",list(italic(t)[1]^"*"==0,italic(t)[2]^"*"==4),")",sep=""))
Lag.spec[14]=expression(paste("Scenario ",5," (",list(italic(t)[1]^"*"==1,italic(t)[2]^"*"==3),")",sep=""))
Lag.spec[15]=expression(paste("Scenario ",5," (",list(italic(t)[1]^"*"==2,italic(t)[2]^"*"==6),")",sep=""))
Result.frame$MERT.num=factor(Result.frame$MERT.num)
levels(Result.frame$MERT.num)[levels(Result.frame$MERT.num)=="1"]<-expression(list(italic(t)[1]^"#"==0,italic(t)[2]^"#"==4))
levels(Result.frame$MERT.num)[levels(Result.frame$MERT.num)=="2"]<-expression(list(italic(t)[1]^"#"==1,italic(t)[2]^"#"==3))
MERT.spec<-rep(NA,2)
MERT.spec[1]<-expression(list(italic(t)[1]^"#"==0,italic(t)[2]^"#"==4))
MERT.spec[2]<-expression(list(italic(t)[1]^"#"==1,italic(t)[2]^"#"==3))
library(ggplot2)
save.image("Figure3.RData")
dev.set()
bitmap("BoshengLi_Figure3.jpeg",type="jpeg",res=800,height=12,width=17.5)
p<-ggplot(Result.frame,aes(x=sqrt.n,y=qnorm.power,colour=Lag.range.num))+geom_line()+geom_point(size=1)
p<-p+labs(colour="Delayed treatment effect\nspecifications")+theme(legend.text=element_text(size=16),legend.title=element_text(size=18),axis.text=element_text(size=16),axis.title=element_text(size=18),strip.text=element_text(size=16))
p<-p+facet_grid(Hazard.ratio~MERT.num+Allc,labeller=label_parsed,scales="free")+xlab("The square root of the maximum sample size")+ylab("The normal quantile of the analytic power function")+scale_color_discrete(labels=Lag.spec)
p
dev.off()
#dev.set()
#bitmap("D:/BoshengLi_Figure32.jpeg",type="jpeg",height=15.45,width=13.5,res=800)
#p<-ggplot(Result.frame,aes(x=sqrt.n,y=qnorm.power,colour=Lag.range.num,linetype=MERT.num))+geom_line()+geom_point(size=1)
#p<-p+facet_grid(Hazard.ratio~Allc,labeller=label_parsed,scales="free_y")+xlab("The square root of the maximum sample size")+ylab("The normal quantile of the analytic power function")+scale_color_discrete(labels=Lag.spec)+scale_linetype_discrete(labels=MERT.spec)
#p<-p+labs(colour="Delayed treatment\neffect specifications")+theme(legend.text=element_text(size=17),legend.title=element_text(size=17),axis.text=element_text(size=16),axis.title=element_text(size=17),strip.text=element_text(size=17))
#p
#dev.off()
