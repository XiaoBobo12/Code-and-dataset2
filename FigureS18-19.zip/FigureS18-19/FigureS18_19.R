setwd("D:/研究备份/研究3/成组序贯设计/模拟情景数据/参数epsilon和b的确定")
data.plot<-data.frame(matrix(nrow=1800,ncol=7))
colnames(data.plot)<-c("Lag.scenario","True.t1.t2","MERT.t1.t2","n1.div.n0","epsilon.b","n","theta")
itr2=0
for(l in 1:6)
{
  load(paste("Scenario.epsilon.b.",l,".RData",sep=""))
  for(itr in 1:300)
  {
    sample.est=sample.est.all[[itr]]
    itr2=itr2+1
    if(sample.est$Parameters$t1.true==sample.est$Parameters$t2.true)
    {
      if(sample.est$Parameters$t1.true<=2)
      {
        data.plot$Lag.scenario[itr2]="Scenario~1"
      }
      else
      {
        data.plot$Lag.scenario[itr2]="Scenario~5"
      }
    }
    else
    {
      if(sample.est$Parameters$a==1&sample.est$Parameters$b==2)
      {
        data.plot$Lag.scenario[itr2]="Scenario~2"
      }
      else if(sample.est$Parameters$a==1&sample.est$Parameters$b==1) 
      {
        data.plot$Lag.scenario[itr2]="Scenario~3"
      }
      else if(sample.est$Parameters$a==2&sample.est$Parameters$b==1) 
      {
        data.plot$Lag.scenario[itr2]="Scenario~4"
      }
    }
    if(sample.est$Parameters$t1.true==0|sample.est$Parameters$t2.true==4)
    {
      data.plot$True.t1.t2[itr2]=1
    }
    else if(sample.est$Parameters$t1.true==1|sample.est$Parameters$t2.true==3)
    {
      data.plot$True.t1.t2[itr2]=2
    }
    else if(sample.est$Parameters$t1.true==2|sample.est$Parameters$t2.true==6)
    {
      data.plot$True.t1.t2[itr2]=3
    }
    if(sample.est$Parameters$t1==0|sample.est$Parameters$t2==4)
    {
      data.plot$MERT.t1.t2[itr2]=1
    }
    else if(sample.est$Parameters$t1==1|sample.est$Parameters$t2==3)
    {
      data.plot$MERT.t1.t2[itr2]=2
    }
    data.plot$n1.div.n0[itr2]=sample.est$Parameters$Allc
    data.plot$epsilon.b[itr2]=paste("(",sample.est$Parameters$interval.period,",",sample.est$Parameters$split.interval.num,")",sep="")
    data.plot$n[itr2]=sample.est$maximum.sample.size
    data.plot$theta[itr2]=sample.est$Parameters$theta
  }
}
data.plot$True.t1.t2=factor(data.plot$True.t1.t2)
levels(data.plot$True.t1.t2)[levels(data.plot$True.t1.t2)==1]=expression(list(italic(t)[1]^"*"==0,italic(t)[2]^"*"==4))
levels(data.plot$True.t1.t2)[levels(data.plot$True.t1.t2)==2]=expression(list(italic(t)[1]^"*"==1,italic(t)[2]^"*"==3))
levels(data.plot$True.t1.t2)[levels(data.plot$True.t1.t2)==3]=expression(list(italic(t)[1]^"*"==2,italic(t)[2]^"*"==6))
data.plot$MERT.t1.t2=factor(data.plot$MERT.t1.t2)
levels(data.plot$MERT.t1.t2)[levels(data.plot$MERT.t1.t2)==1]=expression(list(italic(t)[1]^"#"==0,italic(t)[2]^"#"==4))
levels(data.plot$MERT.t1.t2)[levels(data.plot$MERT.t1.t2)==2]=expression(list(italic(t)[1]^"#"==1,italic(t)[2]^"#"==3))
levels.Allc<-rep(NA,2)
levels.Allc[1]<-"italic(n)[1*italic(K)]/italic(n)[0*italic(K)]==1"
levels.Allc[2]<-"italic(n)[1*italic(K)]/italic(n)[0*italic(K)]==2"
data.plot$Allc[data.plot$n1.div.n0==1]=levels.Allc[1]
data.plot$Allc[data.plot$n1.div.n0==2]=levels.Allc[2]
data.plot=data.plot[,-4]
data.plot.select=data.plot[data.plot$epsilon.b=="(0.1,100)",]
data.plot.select=data.plot.select[,-4]
colnames(data.plot.select)[4]="n.ref"
data.plot.final=merge(data.plot,data.plot.select,by= c("Lag.scenario","True.t1.t2","MERT.t1.t2","Allc","theta"))
data.plot.final$n.dif=data.plot.final$n-data.plot.final$n.ref
library(ggplot2)
dev.set()
bitmap("D:/BoshengLi_FigureS18.jpeg",type="jpeg",width =32,height=18,res=800)
p<-ggplot(data=data.plot.final,mapping = aes(theta,n.dif,colour=epsilon.b))+geom_line()+labs(colour=expression(paste("Combinations of (",epsilon,",b) ")))
p<-p+theme(legend.text=element_text(size=20),legend.title=element_text(size=20),axis.text=element_text(size=18),axis.title=element_text(size=20),strip.text=element_text(size=18))+xlab("Hazard ratio after the full onset of effect")+ylab(expression(paste("The difference in the maximum sample size with that for ",epsilon,"=0.1 and b=100 as reference")))
p<-p+facet_grid(MERT.t1.t2+True.t1.t2~Lag.scenario+Allc,labeller = label_parsed)
p
dev.off()
data.plot.final2=data.plot.final[data.plot.final$epsilon.b!="(10,10)"&data.plot.final$epsilon.b!="(10,100)",]
data.plot.final2$n.dif=data.plot.final2$n.dif+runif(1200,-0.1,0.1)
dev.set()
bitmap("D:/BoshengLi_FigureS19.jpeg",type="jpeg",width =32,height=18,res=800)
p<-ggplot(data=data.plot.final2,mapping = aes(theta,n.dif,colour=epsilon.b))+geom_line()+labs(colour=expression(paste("Combinations of (",epsilon,",b) ")))
p<-p+theme(legend.text=element_text(size=20),legend.title=element_text(size=20),axis.text=element_text(size=18),axis.title=element_text(size=20),strip.text=element_text(size=18))+xlab("Hazard ratio after the full onset of effect")+ylab(expression(paste("The perturbed difference in the maximum sample size with that for ",epsilon,"=0.1 and b=100 as reference")))
p<-p+facet_grid(MERT.t1.t2+True.t1.t2~Lag.scenario+Allc,labeller = label_parsed)
p
dev.off()