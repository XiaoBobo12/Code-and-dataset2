setwd("D:/研究备份/研究3/成组序贯设计/模拟情景数据/延迟起效模型误设的评估")
data.set.plot<-data.frame(matrix(nrow=150,ncol=10))
colnames(data.set.plot)<-c("MERT.t1.t2","TRUE.T1.T2","Hazard.ratio","Assumed.lag.function","Sample.size","Power.t1","Power.t1.t2.1.2","Power.t1.t2.1.1","Power.t1.t2.2.1","Power.t2")
itr.num=0
for(l in 1:6)
{
  load(paste("Scenario.misspecify.lag.",l,".RData",sep=""))
  num=0
  sample.size=-1
  for(i in 1:5)
  {
    theta=theta.vec[i]
    for(j in 1:5)
    {
      itr.num=itr.num+1
      data.set.plot$Hazard.ratio[itr.num]=theta
      data.set.plot$MERT.t1.t2[itr.num]=paste("[",t1,",",t2,"]",sep="")
      data.set.plot$TRUE.T1.T2[itr.num]=paste("[",t1.true,",",t2.true,"]",sep="")
      t1.assumed=lag.set.mat[j,1]
      t2.assumed=lag.set.mat[j,2]
      a.assumed=lag.set.mat[j,3]
      b.assumed=lag.set.mat[j,4]
      if(t1.assumed==t2.assumed)
      {
        if(t1.assumed<=2)
        {
          data.set.plot$Assumed.lag.function[itr.num]="Scenario 1"
        }
        else
        {
          data.set.plot$Assumed.lag.function[itr.num]="Scenario 5"
        }
      }
      else
      {
        if(a.assumed==1&b.assumed==2)
        {
          data.set.plot$Assumed.lag.function[itr.num]="Scenario 2"
        }
        else if(a.assumed==1&b.assumed==1)
        {
          data.set.plot$Assumed.lag.function[itr.num]="Scenario 3"
        }
        else if(a.assumed==2&b.assumed==1)
        {
          data.set.plot$Assumed.lag.function[itr.num]="Scenario 4"
        }
      }
      repeat
      {
        num=num+1
        simul.esti=result.list[[num]]$simul.esti
        if(num%%5==1)
        {
          sample.size=result.list[[num]]$sample.est$maximum.sample.size
          data.set.plot$Sample.size[itr.num]=sample.size
        }
        if(simul.esti$Parameters$t1.true==simul.esti$Parameters$t2.true)
        {
          if(simul.esti$Parameters$t1.true==t1.true)
          {
            data.set.plot$Power.t1[itr.num]=simul.esti$Power
          }
          else
          {
            data.set.plot$Power.t2[itr.num]=simul.esti$Power
          }
        }
        else
        {
          if(simul.esti$Parameters$a==1&simul.esti$Parameters$b==1)
          {
            data.set.plot$Power.t1.t2.1.1[itr.num]=simul.esti$Power
          }
          else if(simul.esti$Parameters$a==1&simul.esti$Parameters$b==2)
          {
            data.set.plot$Power.t1.t2.1.2[itr.num]=simul.esti$Power
          }
          else if(simul.esti$Parameters$a==2&simul.esti$Parameters$b==1)
          {
            data.set.plot$Power.t1.t2.2.1[itr.num]=simul.esti$Power
          }
        }
        if(num<125)
        {
          simul.esti.next=result.list[[num+1]]$simul.esti
          if(sample.size>0&sample.size!=simul.esti.next$Parameters$nc+simul.esti.next$Parameters$nt)
          {
            break
          }
        }
        else
        {
          break
        }
      }
    }
  }
}
data.set.plot2=data.set.plot[order(data.set.plot$MERT.t1.t2,data.set.plot$TRUE.T1.T2,data.set.plot$Hazard.ratio,data.set.plot$Assumed.lag.function),]
write.csv(x=data.set.plot2,file="TableS3.cSv")
