setwd("D:/研究备份/研究3/成组序贯设计/模拟情景数据/成组序贯边界评估/相对于最大样本量")
Mean.matrix<-data.frame(matrix(nrow= 552,ncol=6))
colnames(Mean.matrix)<-c("n","n1.div.n0","Tstar","Method","Analysis","Mean")
Variance.matrix<-data.frame(matrix(nrow=552,ncol=6))
colnames(Variance.matrix)<-c("n","n1.div.n0","Tstar","Method","Analysis","Variance")
covariance.matrix<-data.frame(matrix(nrow=460,ncol=6))
colnames(covariance.matrix)<-c("n","n1.div.n0","Tstar","Method","Type","Covariance")
load("Scenario.Markov.chain.RData")
library(markovchain)
itr=0
for(i in 1:2)
{
  Allc=Allc.vec[i]
  for(j in 1:2)
  {
    t1=t1.t2.matrix[j,1]
    t2=t1.t2.matrix[j,2]
    boundary.list<-group.sequential.boundary.by.markov.chain(tau.vector=tau.vector,A=A,split.interval.num=split.interval.num,interval.period=interval.period,loss.control=loss.control,loss.treatment=loss.treatment,k=k,h0=h0,t1=t1,t2=t2,Allc=Allc,test.type=test.type,Phi.type=Phi.type,alpha=alpha,alpha.allc=alpha.allc,sides=sides)
    bound.list=boundary.list$bound.list
    for(l in 1:23)
    {
      itr=itr+1
      simul.res<-list.result[[itr]]
      list.result[[itr]]<-list(boundary.list=boundary.list,simul.res=simul.res)
      print(itr)
    }
  }
}
for(i in 1:92)
{
  boundary.list=list.result[[i]]$boundary.list
  simul.res=list.result[[i]]$simul.res
  Mean.matrix$n[i*2-1]=simul.res$Parameters$nc+simul.res$Parameters$nt
  Mean.matrix$n[i*2]=simul.res$Parameters$nc+simul.res$Parameters$nt
  Mean.matrix$n1.div.n0[i*2-1]=simul.res$Parameters$nt/simul.res$Parameters$nc
  Mean.matrix$n1.div.n0[i*2]=simul.res$Parameters$nt/simul.res$Parameters$nc
  Mean.matrix$Tstar[i*2-1]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  Mean.matrix$Tstar[i*2]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  Mean.matrix$Method[i*2-1]="Markov~chain-based~method"
  Mean.matrix$Method[i*2]="Markov~chain-based~method"
  Mean.matrix$Analysis[i*2-1]="Interim~analysis"
  Mean.matrix$Analysis[i*2]="Final~analysis"
  Mean.matrix$Mean[i*2-1]=simul.res$Distribution$mean.test.statistics.std[1]
  Mean.matrix$Mean[i*2]=simul.res$Distribution$mean.test.statistics.std[2]
  Variance.matrix$n[i*2-1]=simul.res$Parameters$nc+simul.res$Parameters$nt
  Variance.matrix$n[i*2]=simul.res$Parameters$nc+simul.res$Parameters$nt
  Variance.matrix$n1.div.n0[i*2-1]=simul.res$Parameters$nt/simul.res$Parameters$nc
  Variance.matrix$n1.div.n0[i*2]=simul.res$Parameters$nt/simul.res$Parameters$nc
  Variance.matrix$Tstar[i*2-1]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  Variance.matrix$Tstar[i*2]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  Variance.matrix$Method[i*2-1]="Markov~chain-based~method"
  Variance.matrix$Method[i*2]="Markov~chain-based~method"
  Variance.matrix$Analysis[i*2-1]="Interim~analysis"
  Variance.matrix$Analysis[i*2]="Final~analysis"
  Variance.matrix$Variance[i*2-1]=simul.res$Distribution$Var.test.statistics.matrix.std[1,1]
  Variance.matrix$Variance[i*2]=simul.res$Distribution$Var.test.statistics.matrix.std[1,1]
  covariance.matrix$n[i*2-1]=simul.res$Parameters$nc+simul.res$Parameters$nt
  covariance.matrix$n[i*2]=simul.res$Parameters$nc+simul.res$Parameters$nt
  covariance.matrix$n1.div.n0[i*2-1]=simul.res$Parameters$nt/simul.res$Parameters$nc
  covariance.matrix$n1.div.n0[i*2]=simul.res$Parameters$nt/simul.res$Parameters$nc
  covariance.matrix$Tstar[i*2-1]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  covariance.matrix$Tstar[i*2]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  covariance.matrix$Method[i*2-1]="Markov chain-\n-based method"
  covariance.matrix$Method[i*2]="Markov chain-\n-based method"
  covariance.matrix$Type[i*2-1]="Asymptotical"
  covariance.matrix$Type[i*2]="Empirical"
  covariance.matrix$Covariance[i*2-1]=boundary.list$covariance.matrix[1,2]
  covariance.matrix$Covariance[i*2]=simul.res$Distribution$Var.test.statistics.matrix.std[1,2]
}
load("Scenario.integration.RData")
itr=0
for(i in 1:2)
{
  Allc=Allc.vec[i]
  for(j in 1:2)
  {
    t1=t1.t2.matrix[j,1]
    t2=t1.t2.matrix[j,2]
    boundary.list<-group.sequential.boundary.integration.method(tau.vector=tau.vector,A=A,loss.control=loss.control,loss.treatment=loss.treatment,k=k,h0=h0,t1=t1,t2=t2,Allc=Allc,alpha=alpha,alpha.allc=alpha.allc,sides=sides)
    bound.list=boundary.list$bound.list
    for(l in 1:23)
    {
      itr=itr+1
      simul.res<-list.result[[itr]]
      list.result[[itr]]<-list(boundary.list=boundary.list,simul.res=simul.res)
      print(itr)
    }
  }
}
for(i in 1:92)
{
  boundary.list=list.result[[i]]$boundary.list
  simul.res=list.result[[i]]$simul.res
  Mean.matrix$n[184+i*2-1]=simul.res$Parameters$nc+simul.res$Parameters$nt
  Mean.matrix$n[184+i*2]=simul.res$Parameters$nc+simul.res$Parameters$nt
  Mean.matrix$n1.div.n0[184+i*2-1]=simul.res$Parameters$nt/simul.res$Parameters$nc
  Mean.matrix$n1.div.n0[184+i*2]=simul.res$Parameters$nt/simul.res$Parameters$nc
  Mean.matrix$Tstar[184+i*2-1]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  Mean.matrix$Tstar[184+i*2]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  Mean.matrix$Method[184+i*2-1]="Integration-based~method"
  Mean.matrix$Method[184+i*2]="Integration-based~method"
  Mean.matrix$Analysis[184+i*2-1]="Interim~analysis"
  Mean.matrix$Analysis[184+i*2]="Final~analysis"
  Mean.matrix$Mean[184+i*2-1]=simul.res$Distribution$mean.test.statistics.std[1]
  Mean.matrix$Mean[184+i*2]=simul.res$Distribution$mean.test.statistics.std[2]
  Variance.matrix$n[184+i*2-1]=simul.res$Parameters$nc+simul.res$Parameters$nt
  Variance.matrix$n[184+i*2]=simul.res$Parameters$nc+simul.res$Parameters$nt
  Variance.matrix$n1.div.n0[184+i*2-1]=simul.res$Parameters$nt/simul.res$Parameters$nc
  Variance.matrix$n1.div.n0[184+i*2]=simul.res$Parameters$nt/simul.res$Parameters$nc
  Variance.matrix$Tstar[184+i*2-1]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  Variance.matrix$Tstar[184+i*2]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  Variance.matrix$Method[184+i*2-1]="Integration-based~method"
  Variance.matrix$Method[184+i*2]="Integration-based~method"
  Variance.matrix$Analysis[184+i*2-1]="Interim~analysis"
  Variance.matrix$Analysis[184+i*2]="Final~analysis"
  Variance.matrix$Variance[184+i*2-1]=simul.res$Distribution$Var.test.statistics.matrix.std[1,1]
  Variance.matrix$Variance[184+i*2]=simul.res$Distribution$Var.test.statistics.matrix.std[1,1]
  covariance.matrix$n[184+i*2-1]=simul.res$Parameters$nc+simul.res$Parameters$nt
  covariance.matrix$n[184+i*2]=simul.res$Parameters$nc+simul.res$Parameters$nt
  covariance.matrix$n1.div.n0[184+i*2-1]=simul.res$Parameters$nt/simul.res$Parameters$nc
  covariance.matrix$n1.div.n0[184+i*2]=simul.res$Parameters$nt/simul.res$Parameters$nc
  covariance.matrix$Tstar[184+i*2-1]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  covariance.matrix$Tstar[184+i*2]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  covariance.matrix$Method[184+i*2-1]="Integration-\n-based method"
  covariance.matrix$Method[184+i*2]="Integration-\n-based method"
  covariance.matrix$Type[184+i*2-1]="Asymptotical"
  covariance.matrix$Type[184+i*2]="Empirical"
  covariance.matrix$Covariance[184+i*2-1]=boundary.list$covariance.matrix[1,2]
  covariance.matrix$Covariance[184+i*2]=simul.res$Distribution$Var.test.statistics.matrix.std[1,2]
}
load("Scenario.simulation.RData")
for(i in 1:92)
{
  simul.res=list.result[[i]]
  Mean.matrix$n[368+i*2-1]=simul.res$Parameters$nc+simul.res$Parameters$nt
  Mean.matrix$n[368+i*2]=simul.res$Parameters$nc+simul.res$Parameters$nt
  Mean.matrix$n1.div.n0[368+i*2-1]=simul.res$Parameters$nt/simul.res$Parameters$nc
  Mean.matrix$n1.div.n0[368+i*2]=simul.res$Parameters$nt/simul.res$Parameters$nc
  Mean.matrix$Tstar[368+i*2-1]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  Mean.matrix$Tstar[368+i*2]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  Mean.matrix$Method[368+i*2-1]="Simulation-based~method"
  Mean.matrix$Method[368+i*2]="Simulation-based~method"
  Mean.matrix$Analysis[368+i*2-1]="Interim~analysis"
  Mean.matrix$Analysis[368+i*2]="Final~analysis"
  Mean.matrix$Mean[368+i*2-1]=simul.res$Distribution$mean.test.statistics.std[1]
  Mean.matrix$Mean[368+i*2]=simul.res$Distribution$mean.test.statistics.std[2]
  Variance.matrix$n[368+i*2-1]=simul.res$Parameters$nc+simul.res$Parameters$nt
  Variance.matrix$n[368+i*2]=simul.res$Parameters$nc+simul.res$Parameters$nt
  Variance.matrix$n1.div.n0[368+i*2-1]=simul.res$Parameters$nt/simul.res$Parameters$nc
  Variance.matrix$n1.div.n0[368+i*2]=simul.res$Parameters$nt/simul.res$Parameters$nc
  Variance.matrix$Tstar[368+i*2-1]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  Variance.matrix$Tstar[368+i*2]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  Variance.matrix$Method[368+i*2-1]="Simulation-based~method"
  Variance.matrix$Method[368+i*2]="Simulation-based~method"
  Variance.matrix$Analysis[368+i*2-1]="Interim~analysis"
  Variance.matrix$Analysis[368+i*2]="Final~analysis"
  Variance.matrix$Variance[368+i*2-1]=simul.res$Distribution$Var.test.statistics.matrix.std[1,1]
  Variance.matrix$Variance[368+i*2]=simul.res$Distribution$Var.test.statistics.matrix.std[1,1]
  covariance.matrix$n[368+i]=simul.res$Parameters$nc+simul.res$Parameters$nt
  covariance.matrix$n1.div.n0[368+i]=simul.res$Parameters$nt/simul.res$Parameters$nc
  covariance.matrix$Tstar[368+i]=paste("[",simul.res$Parameters$t1,",",simul.res$Parameters$t2,"]",sep="")
  covariance.matrix$Method[368+i]="Simulation-based~method"
  covariance.matrix$Type[368+i]="Empirical"
  covariance.matrix$Covariance[368+i]=simul.res$Distribution$Var.test.statistics.matrix.std[1,2]
}
Mean.matrix$Tstar.order[Mean.matrix$Tstar=="[1,3]"]=1
Mean.matrix$Tstar.order[Mean.matrix$Tstar=="[0,4]"]=2
Mean.matrix$Tstar.order=factor(Mean.matrix$Tstar.order)
levels.tstar<-rep(NA,2)
levels.tstar[1]=expression(list(italic(t)[1]^"#"==1,italic(t)[2]^"#"==3))
levels.tstar[2]=expression(list(italic(t)[1]^"#"==0,italic(t)[2]^"#"==4))
levels.Allc<-rep(NA,2)
levels.Allc[1]<-"italic(n)[1*italic(K)]/italic(n)[0*italic(K)]==1"
levels.Allc[2]<-"italic(n)[1*italic(K)]/italic(n)[0*italic(K)]==2"
Mean.matrix$Allc[Mean.matrix$n1.div.n0==1]=levels.Allc[1]
Mean.matrix$Allc[Mean.matrix$n1.div.n0==2]=levels.Allc[2]
library(ggplot2)
dev.set()
bitmap("D:/BoshengLi_FigureS5.jpeg",type="jpeg",height =8 ,width=16,res=800)
p1<-ggplot(data=Mean.matrix,aes(x=n,y=Mean,colour=Tstar.order))+geom_point(size=1)+scale_color_discrete(labels=levels.tstar)+geom_point(size=1)+labs(colour=expression(paste(italic(t)[1]^"#"," and ",italic(t)[2]^"#"," of ","MERT")))+theme(legend.text=element_text(size=17),legend.title=element_text(size=17),axis.text=element_text(size=16),axis.title=element_text(size=17),strip.text=element_text(size=16))+xlab("Maximum sample size")+ylab("Empirical mean")
p1<-p1+facet_wrap(Allc~Analysis,labeller = label_parsed)+scale_x_continuous(breaks=seq(60,720,120))
p1
dev.off()
Variance.matrix$Tstar.order[Variance.matrix$Tstar=="[1,3]"]=1
Variance.matrix$Tstar.order[Variance.matrix$Tstar=="[0,4]"]=2
Variance.matrix$Tstar.order=factor(Variance.matrix$Tstar.order)
levels.tstar<-rep(NA,2)
levels.tstar[1]=expression(list(italic(t)[1]^"#"==1,italic(t)[2]^"#"==3))
levels.tstar[2]=expression(list(italic(t)[1]^"#"==0,italic(t)[2]^"#"==4))
levels.Allc<-rep(NA,2)
levels.Allc[1]<-"italic(n)[1*italic(K)]/italic(n)[0*italic(K)]==1"
levels.Allc[2]<-"italic(n)[1*italic(K)]/italic(n)[0*italic(K)]==2"
Variance.matrix$Allc[Variance.matrix$n1.div.n0==1]=levels.Allc[1]
Variance.matrix$Allc[Variance.matrix$n1.div.n0==2]=levels.Allc[2]
dev.set()
bitmap("D:/BoshengLi_FigureS6.jpeg",type="jpeg",height =8 ,width=16,res=800)
p1<-ggplot(data=Variance.matrix,aes(x=n,y=Variance,colour=Tstar.order))+geom_point(size=1)+scale_color_discrete(labels=levels.tstar)+geom_point(size=1)+labs(colour=expression(paste(italic(t)[1]^"#"," and ",italic(t)[2]^"#"," of ","MERT")))+theme(legend.text=element_text(size=17),legend.title=element_text(size=17),axis.text=element_text(size=16),axis.title=element_text(size=17),strip.text=element_text(size=16))+xlab("Maximum sample size")+ylab("Empirical Variance")
p1<-p1+facet_wrap(Allc~Analysis,labeller = label_parsed)+scale_x_continuous(breaks=seq(60,720,120))
p1
dev.off()
covariance.matrix$Tstar.order[covariance.matrix$Tstar=="[1,3]"]=1
covariance.matrix$Tstar.order[covariance.matrix$Tstar=="[0,4]"]=2
covariance.matrix$Tstar.order=factor(covariance.matrix$Tstar.order)
levels.tstar<-rep(NA,2)
levels.tstar[1]=expression(list(italic(t)[1]^"#"==1,italic(t)[2]^"#"==3))
levels.tstar[2]=expression(list(italic(t)[1]^"#"==0,italic(t)[2]^"#"==4))
levels.Allc<-rep(NA,2)
levels.Allc[1]<-"italic(n)[1*italic(K)]/italic(n)[0*italic(K)]==1"
levels.Allc[2]<-"italic(n)[1*italic(K)]/italic(n)[0*italic(K)]==2"
covariance.matrix$Allc[covariance.matrix$n1.div.n0==1]=levels.Allc[1]
covariance.matrix$Allc[covariance.matrix$n1.div.n0==2]=levels.Allc[2]
covariance.matrix.Empirical=covariance.matrix[covariance.matrix$Type=="Empirical",]
covariance.matrix.Asymptotical=covariance.matrix[covariance.matrix$Type=="Asymptotical",]
dev.set()
bitmap("D:/BoshengLi_FigureS7.jpeg",type="jpeg",height =5 ,width=16,res=800)
p<-ggplot(data=covariance.matrix.Empirical,aes(x=n,y=Covariance,colour=Tstar.order))+geom_point()+geom_line(data=covariance.matrix.Asymptotical,mapping = aes(x=n,y=Covariance,linetype=Method))
p<-p+labs(colour=expression(paste(italic(t)[1]^"#"," and ",italic(t)[2]^"#"," of ","MERT")),linetype="Asymptotical method")+theme(legend.text=element_text(size=17),legend.title=element_text(size=17),axis.text=element_text(size=16),axis.title=element_text(size=17),strip.text=element_text(size=16))+xlab("Maximum sample size")+ylab("Covariance")
p<-p+facet_wrap(Allc~.,labeller = label_parsed,ncol=2)+scale_x_continuous(breaks=seq(60,720,120))+scale_color_discrete(labels=levels.tstar)
p
dev.off()