rm(list=ls())
setwd("D:/�о�����/�о�3/����������/ģ���龰����/�������߽�����/��������������")
load("Scenario.Markov.chain.RData")
results<-data.frame(matrix(nrow=92,ncol=8))
colnames(results)<-c("n","n1.div.n0","Type.one.error","Ratio.Type.one.error","t1","t2","Tstar","Allc")
for(i in 1:92)
{
  results[i,1]=list.result[[i]]$Parameters$nc+list.result[[i]]$Parameters$nt
  results[i,2]=list.result[[i]]$Parameters$nt/list.result[[i]]$Parameters$nc
  results[i,3]=list.result[[i]]$Power
  results[i,4]=list.result[[i]]$Power.respective[1]/list.result[[i]]$Power.respective[2]
  results[i,5]=list.result[[i]]$Parameters$t1
  results[i,6]=list.result[[i]]$Parameters$t2
}
levels.Allc<-rep(NA,2)
levels.Allc[1]<-"italic(n)[1*italic(K)]/italic(n)[0*italic(K)]==1"
levels.Allc[2]<-"italic(n)[1*italic(K)]/italic(n)[0*italic(K)]==2"
results$Allc[results$n1.div.n0==1]=levels.Allc[1]
results$Allc[results$n1.div.n0==2]=levels.Allc[2]
levels.tstar<-rep(NA,2)
levels.tstar[1]<-expression(list(italic(t)[1]^"#"==1,italic(t)[2]^"#"==3))
levels.tstar[2]<-expression(list(italic(t)[1]^"#"==0,italic(t)[2]^"#"==4))
results$Tstar[results$t1==1&results$t2==3]="1"
results$Tstar[results$t1==0&results$t2==4]="2"
library(ggplot2)
library(gridExtra)
dev.set()
bitmap("D:/BoshengLi_Figure1.jpeg",type="jpeg",height =12.5 ,width = 22,res=800)
p1<-ggplot(data=results,aes(x=n,y=Type.one.error,colour=Tstar))+geom_line(size=1)+scale_color_discrete(labels=levels.tstar)+geom_point(size=1)+labs(colour=expression(paste(italic(t)[1]^"#"," and ",italic(t)[2]^"#"," of ","MERT")))+theme(legend.text=element_text(size=17),legend.title=element_text(size=17),axis.text=element_text(size=16),axis.title=element_text(size=17),strip.text=element_text(size=16))+xlab("Maximum sample size")+ylab(paste("Empirical type ",as.roman(1)," error rate",sep=""))
p1<-p1+facet_wrap(Allc~.,labeller = label_parsed,ncol=1,scales="free_y")+scale_x_continuous(breaks=seq(60,720,120))
p2<-ggplot(data=results,aes(x=n,y=Ratio.Type.one.error,colour=Tstar))+geom_line(size=1)+scale_color_discrete(labels=levels.tstar)+geom_point(size=1)+labs(colour=expression(paste(italic(t)[1]^"#"," and ",italic(t)[2]^"#"," of ","MERT")))+theme(legend.text=element_text(size=17),legend.title=element_text(size=17),axis.text=element_text(size=16),axis.title=element_text(size=17),strip.text=element_text(size=16))+xlab("Maximum sample size")+ylab(paste("Empirical ratio of the stepwise type",as.roman(1),"error rates of the interm and final analyses",sep=" "))
p2<-p2+facet_wrap(Allc~.,labeller = label_parsed,ncol=1,scales="free_y")+scale_x_continuous(breaks=seq(60,720,120))
grid.arrange(p1, p2, nrow=1)
dev.off()