rm(list=ls())
load("D:/ario2.integration.RData")
results<-data.frame(matrix(nrow=484,ncol=9))
colnames(results)<-c("k","h0","n1.div.n0","Type.one.error","Ratio.Type.one.error","t1","t2","Tstar","Allc")
for(i in 1:484)
{
  results[i,1]=list.result[[i]]$simul.res$Parameters$k
  results[i,2]=list.result[[i]]$simul.res$Parameters$h0
  results[i,3]=list.result[[i]]$simul.res$Parameters$nt/list.result[[i]]$simul.res$Parameters$nc
  results[i,4]=list.result[[i]]$simul.res$Power
  results[i,5]=list.result[[i]]$simul.res$Power.respective[1]/list.result[[i]]$simul.res$Power.respective[2]
  results[i,6]=list.result[[i]]$simul.res$Parameters$t1
  results[i,7]=list.result[[i]]$simul.res$Parameters$t2
}
levels.Allc<-rep(NA,2)
levels.Allc[1]<-"italic(n)[1*italic(K)]/italic(n)[0*italic(K)]==1"
levels.Allc[2]<-"italic(n)[1*italic(K)]/italic(n)[0*italic(K)]==2"
results$Allc[results$n1.div.n0==1]=levels.Allc[1]
results$Allc[results$n1.div.n0==2]=levels.Allc[2]
levels.tstar<-rep(NA,2)
levels.tstar[1]<-expression(list(italic(t)[1]^"#"==1,italic(t)[2]^"#"==3))
levels.tstar[2]<-expression(list(italic(t)[1]^"#"==0,italic(t)[2]^"#"==4))
results$Tstar[results$t1==1&results$t2==3]=1
results$Tstar[results$t1==0&results$t2==4]=2
results$Tstar<-factor(results$Tstar)
levels(results$Tstar)[levels(results$Tstar)==1]=levels.tstar[1]
levels(results$Tstar)[levels(results$Tstar)==2]=levels.tstar[2]
library(gridExtra)
library(ggplot2)
dev.set()
bitmap("D:/BoshengLi_FigureA3.jSeg",type="jpeg",height =22 ,width=14,res=800)
p1<-ggplot(data=results,aes(x=k,y=h0))+geom_raster(aes(fill=Type.one.error),interpolate = TRUE)+scale_fill_gradientn(colours =c("purple","blue","cyan","green","yellow","orange","red"))+theme(legend.text=element_text(size=17),legend.title=element_text(size=17),axis.text=element_text(size=16),axis.title=element_text(size=17),strip.text=element_text(size=16))
p1<-p1+labs(fill=paste("Empirical\ntype",as.roman(1),"error\nprobability"))+xlab(expression(x=italic(k)))+ylab(expression(y=italic(h)[0]))
p1<-p1+facet_wrap(Allc~Tstar,labeller = label_parsed,ncol=1)
p2<-ggplot(data=results,aes(x=k,y=h0))+geom_raster(aes(fill=Ratio.Type.one.error),interpolate = TRUE)+scale_fill_gradientn(colours =c("purple","blue","cyan","green","yellow","orange","red"))+theme(legend.text=element_text(size=17),legend.title=element_text(size=17),axis.text=element_text(size=16),axis.title=element_text(size=17),strip.text=element_text(size=16))
p2<-p2+labs(fill=paste("Empirical ratio of\ntype",as.roman(1),"error rates\n of the interim and\nfinal analysis"))+xlab(expression(x=italic(k)))+ylab(expression(y=italic(h)[0]))
p2<-p2+facet_wrap(Allc~Tstar,labeller = label_parsed,ncol=1)
grid.arrange(p1, p2, nrow=1)
dev.off()