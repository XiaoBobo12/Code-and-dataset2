setwd("D:/研究备份/研究3/成组序贯设计/模拟情景数据/误设延迟范围的敏感性分析")
result.all<-data.frame(matrix(nrow=75,ncol=11))
colnames(result.all)<-c("Hazard.ratio","Lag.Scenario","TRUE.t1.t2","MERT.0.4.Sample.size.estimation","MERT.0.4.TRUE.0.4","MERT.0.4.TRUE.1.3","MERT.0.4.TRUE.2.6","MERT.1.3.Sample.size.estimation","MERT.1.3.TRUE.0.4","MERT.1.3.TRUE.1.3","MERT.1.3.TRUE.2.6")
for(ii in 1:6)
{
  str=paste("Scenario.misspecify.range.",ii,".RData",sep="")
  if(ii==1|ii==4)
  {
    base=0
  }else if(ii==2|ii==5)
  {
    base=25
  }else if(ii==3|ii==6)
  {
    base=50
  }
  load(str)
  for(jj in 1:75)
  {
    row=base+ceiling(jj/3)
    if(jj%%3==1)
    {
      result.all$Hazard.ratio[row]=result.list[[jj]]$sample.est$Parameters$theta
      if(result.list[[jj]]$sample.est$Parameters$t1.true==result.list[[jj]]$sample.est$Parameters$t2.true)
      {
        if(result.list[[jj]]$sample.est$Parameters$t1.true<=2)
        {
          result.all$Lag.Scenario[row]="Scenario 1"
        }
        else
        {
          result.all$Lag.Scenario[row]="Scenario 5"
        }
      }
      else
      {
        if(result.list[[jj]]$sample.est$Parameters$a==1&result.list[[jj]]$sample.est$Parameters$b==2)
        {
          result.all$Lag.Scenario[row]="Scenario 2"
        }
        if(result.list[[jj]]$sample.est$Parameters$a==1&result.list[[jj]]$sample.est$Parameters$b==1)
        {
          result.all$Lag.Scenario[row]="Scenario 3"
        }
        if(result.list[[jj]]$sample.est$Parameters$a==2&result.list[[jj]]$sample.est$Parameters$b==1)
        {
          result.all$Lag.Scenario[row]="Scenario 4"
        }
      }
      result.all$TRUE.t1.t2[row]=paste("[",t1.assumed,",",t2.assumed,"]",sep="")
      if(t1==0&t2==4)
      {
        result.all$MERT.0.4.Sample.size.estimation[row]=result.list[[jj]]$sample.est$maximum.sample.size
      }
      else
      {
        result.all$MERT.1.3.Sample.size.estimation[row]=result.list[[jj]]$sample.est$maximum.sample.size
      }
    }
    if(result.list[[jj]]$simul.esti$Parameters$t1==0&result.list[[jj]]$simul.esti$Parameters$t2==4)
    {
      if(result.list[[jj]]$simul.esti$Parameters$t1.true==0|result.list[[jj]]$simul.esti$Parameters$t2.true==4)
      {
        result.all$MERT.0.4.TRUE.0.4[row]=result.list[[jj]]$simul.esti$Power
      }
      else if(result.list[[jj]]$simul.esti$Parameters$t1.true==1|result.list[[jj]]$simul.esti$Parameters$t2.true==3)
      {
        result.all$MERT.0.4.TRUE.1.3[row]=result.list[[jj]]$simul.esti$Power
      }
      else if(result.list[[jj]]$simul.esti$Parameters$t1.true==2|result.list[[jj]]$simul.esti$Parameters$t2.true==6)
      {
        result.all$MERT.0.4.TRUE.2.6[row]=result.list[[jj]]$simul.esti$Power
      }
    }
    else
    {
      if(result.list[[jj]]$simul.esti$Parameters$t1.true==0|result.list[[jj]]$simul.esti$Parameters$t2.true==4)
      {
        result.all$MERT.1.3.TRUE.0.4[row]=result.list[[jj]]$simul.esti$Power
      }
      else if(result.list[[jj]]$simul.esti$Parameters$t1.true==1|result.list[[jj]]$simul.esti$Parameters$t2.true==3)
      {
        result.all$MERT.1.3.TRUE.1.3[row]=result.list[[jj]]$simul.esti$Power
      }
      else if(result.list[[jj]]$simul.esti$Parameters$t1.true==2|result.list[[jj]]$simul.esti$Parameters$t2.true==6)
      {
        result.all$MERT.1.3.TRUE.2.6[row]=result.list[[jj]]$simul.esti$Power
      }
    }
  }
}
result.all2=result.all[order(result.all$Hazard.ratio,result.all$Lag.Scenario,result.all$TRUE.t1.t2),]
write.csv(x=result.all2,file="TableS4.csv")